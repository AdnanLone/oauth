Start the application with:

```
CLIENT_ID=<github id> CLIENT_SECRET=<github secret> CONSUMER_KEY=<twitter key> CONSUMER_SECRET=<twitter secret> ./bin/www
```
